import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { Student, Grade, UserRole } from '../backend';
import { Principal } from '@dfinity/principal';

// Role Queries
export function useGetCallerUserRole() {
  const { actor, isFetching } = useActor();

  return useQuery<UserRole>({
    queryKey: ['userRole'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserRole();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useIsCallerAdmin() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isAdmin'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAssignUserRole() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ principal, role }: { principal: string; role: UserRole }) => {
      if (!actor) throw new Error('Actor not available');
      await actor.assignCallerUserRole(Principal.fromText(principal), role);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userRole'] });
    },
  });
}

// Student Queries
export function useGetAllStudents() {
  const { actor, isFetching } = useActor();

  return useQuery<Student[]>({
    queryKey: ['students'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllStudents();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetAllStudentsByClass() {
  const { actor, isFetching } = useActor();

  return useQuery<Student[]>({
    queryKey: ['studentsByClass'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllStudentsByClass();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSearchStudents(searchText: string) {
  const { actor, isFetching } = useActor();

  return useQuery<Student[]>({
    queryKey: ['students', 'search', searchText],
    queryFn: async () => {
      if (!actor || !searchText) return [];
      return actor.searchStudents(searchText);
    },
    enabled: !!actor && !isFetching && !!searchText,
  });
}

export function useGetStudent(id: bigint | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Student>({
    queryKey: ['student', id?.toString()],
    queryFn: async () => {
      if (!actor || id === null) throw new Error('Invalid parameters');
      return actor.getStudent(id);
    },
    enabled: !!actor && !isFetching && id !== null,
  });
}

export function useAddStudent() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ name, className }: { name: string; className: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addStudent(name, className);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      queryClient.invalidateQueries({ queryKey: ['studentsByClass'] });
    },
  });
}

export function useUpdateStudent() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, name, className }: { id: bigint; name: string; className: string }) => {
      if (!actor) throw new Error('Actor not available');
      await actor.updateStudent(id, name, className);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      queryClient.invalidateQueries({ queryKey: ['studentsByClass'] });
      queryClient.invalidateQueries({ queryKey: ['student'] });
    },
  });
}

export function useDeleteStudent() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error('Actor not available');
      await actor.deleteStudent(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['students'] });
      queryClient.invalidateQueries({ queryKey: ['studentsByClass'] });
      queryClient.invalidateQueries({ queryKey: ['grades'] });
    },
  });
}

// Grade Queries
export function useGetGradesForStudent(studentId: bigint | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Grade[]>({
    queryKey: ['grades', 'student', studentId?.toString()],
    queryFn: async () => {
      if (!actor || studentId === null) return [];
      return actor.getGradesForStudent(studentId);
    },
    enabled: !!actor && !isFetching && studentId !== null,
  });
}

export function useGetAllGrades() {
  const { actor, isFetching } = useActor();

  return useQuery<Grade[]>({
    queryKey: ['grades'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllGrades();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddGrade() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ studentId, subject, score }: { studentId: bigint; subject: string; score: bigint }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addGrade(studentId, subject, score);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grades'] });
    },
  });
}

export function useUpdateGrade() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, studentId, subject, score }: { id: bigint; studentId: bigint; subject: string; score: bigint }) => {
      if (!actor) throw new Error('Actor not available');
      await actor.updateGrade(id, studentId, subject, score);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grades'] });
    },
  });
}

export function useDeleteGrade() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error('Actor not available');
      await actor.deleteGrade(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grades'] });
    },
  });
}

// Parent Queries
export function useGetChildForParent() {
  const { actor, isFetching } = useActor();

  return useQuery<Student>({
    queryKey: ['parentChild'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getChildForParent();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetGradesForParentChild() {
  const { actor, isFetching } = useActor();

  return useQuery<Grade[]>({
    queryKey: ['parentChildGrades'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getGradesForParentChild();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useLinkParentToStudent() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ parentPrincipal, studentId }: { parentPrincipal: string; studentId: bigint }) => {
      if (!actor) throw new Error('Actor not available');
      await actor.linkParentToStudent(Principal.fromText(parentPrincipal), studentId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['parentChild'] });
    },
  });
}
